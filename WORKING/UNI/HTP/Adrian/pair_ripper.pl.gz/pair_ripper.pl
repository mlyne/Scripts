#!/usr/bin/perl

$single_file = $ARGV[0];
$main_file   = $ARGV[1];
$file_type   = $ARGV[2]; #default fq, specify if fa

open $FILEA, "< $single_file";
open $FILEB, "< $main_file";

while (<$FILEA>) {

if ($file_type eq "fa"){$_ =~ /^>(.+)#\d\/\d$/;
    $pair_identifiers{$1} = 1;}else{

    $_ =~ /^@(.+)#\d\/\d$/;
    $pair_identifiers{$1} = 1;
}
    $_                    = <$FILEA>;
unless ($file_type eq "fa"){
    $_                    = <$FILEA>;
    $_                    = <$FILEA>;
}

}

while (<$FILEB>) {
    $_ =~ /^@(.+)#\d\/\d$/;

    if ( $pair_identifiers{$1} ) {
        print $_;
        $_ = <$FILEB>;
        print $_;
        $_ = <$FILEB>;
        print $_;
        $_ = <$FILEB>;
        print $_;
    }
    else {
        $_ = <$FILEB>;
        $_ = <$FILEB>;
        $_ = <$FILEB>;
    }

}

