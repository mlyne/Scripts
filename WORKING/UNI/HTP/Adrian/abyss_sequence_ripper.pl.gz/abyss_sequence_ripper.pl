#!/usr/bin/perl
use warnings;

$identifier_file = $ARGV[0];
$sequence_file = $ARGV[1];
$pos_neg = $ARGV[2];

open IN, "$identifier_file" or die "can't open file";
while (<IN>) {
   chomp $_;
$identifier{$_} = 1;
}
close IN;

open IN, "$sequence_file" or die "can't open file";
while (<IN>) {
   chomp $_;
   if ( $_ =~ m/^>/ ) {
       if ($current_seq) {
           $sequences_index{$current_header} = "$current_seq";
		$current_seq = undef;
       }
       $current_header = $_;
      


   }
   else {
       $_ = uc($_);
       $current_seq .= "$_";
   }
}

$sequences_index{$current_header} = "$current_seq";
close IN;

foreach $header (keys %sequences_index){
$header =~ />(\d+)\s/;
$subheader = $1;


if ($identifier{$subheader}){
if ($pos_neg eq "pos"){ 
print "$header\n$sequences_index{$header}\n";}
}else{
if ($pos_neg eq "neg"){ 
print "$header\n$sequences_index{$header}\n";}
}


}


