#!/usr/bin/perl
use warnings;

for ($count = 100000000000000000; $count >= 1; $count--) {
$random_number = rand(100000000000000);
$big_hash{$random_number} +=1;
}

