#!/usr/bin/perl
use warnings;
use List::Util 'shuffle';


# start timer
my $start = time();

##list FASTA files to use in an array

$input = "boris/student0.txt";
$output = "boris/student0.fa";
open( OUT, ">$output" ) or die "can't open file";
open IN, "$input" or die "can't open file";

@sequences_original = ();

while (<IN>) {
	chomp $_;
	push(@sequences_original, "$_");
	}


	$counter =  1;
	foreach (@sequences_original) {
	print OUT ">SEQUENCE_$counter\n";
	print OUT "$_\n";
	$counter+=1;
	}

close OUT;


# end timer
my $end = time();

# report
print "\nTime taken was ", ( $end - $start ), " seconds\n";


