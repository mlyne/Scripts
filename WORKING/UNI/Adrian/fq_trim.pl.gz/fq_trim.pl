#!/usr/bin/perl

$filenameA = $ARGV[0];
$filenameOut = $ARGV[1];
$length = $ARGV[2];

open $FILEA, "< $filenameA";

open $OUTFILE, "> $filenameOut";

while(<$FILEA>) {
    
        print $OUTFILE $_;
        $_ = <$FILEA>;
        chomp $_;
        $_ = unpack("x0 A$length", $_);
        print $OUTFILE $_; 
        print $OUTFILE "\n"; 

        $_ = <$FILEA>;
       print $OUTFILE "+\n"; 
        $_ = <$FILEA>;
        chomp $_;
        $_ = unpack("x0 A$length", $_);
        print $OUTFILE "$_"; 
        print $OUTFILE "\n"; 
        
}
