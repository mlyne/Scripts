#!/usr/bin/perl

$filenameA = $ARGV[0];
$filenameB = $ARGV[1];

open $FILEA, "< $filenameA";
open $FILEB, "< $filenameB";

while(<$FILEA>) {
        print $_;
        $_ = <$FILEA>;
        print $_; 
		$_ = <$FILEB>;
        print $_; 
        $_ = <$FILEB>;
        print $_;
}
