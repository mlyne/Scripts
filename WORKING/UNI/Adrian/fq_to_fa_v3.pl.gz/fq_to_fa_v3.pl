#!/usr/bin/perl

while(<>) {
        $_ =~ s/^@/>/;
        print $_;
        $_ = <>;
        print $_; 
		<>;
        <>;
}
