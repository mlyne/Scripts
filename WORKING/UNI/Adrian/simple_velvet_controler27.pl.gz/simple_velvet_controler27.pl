#!/usr/bin/perl
use warnings;

# start timer
my $start = time();

$output = `velvetg /./local/adrian/rotifer_500_800/velvet/test_500_800_new_27 -cov_cutoff 8 -exp_cov 80 -exp_cov auto -cov_cutoff auto 2>/dev/null`;
@output = split(/\n/, $output);

foreach(@output){print "$_\n";}         

# end timer
my $end = time();

# report
print "\nTime taken was ", ( $end - $start ), " seconds\n";


