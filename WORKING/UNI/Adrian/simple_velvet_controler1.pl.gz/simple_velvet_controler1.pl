#!/usr/bin/perl
use warnings;

# start timer
my $start = time();

$output = `velvetg /./local/adrian/check_assignment/test -exp_cov auto -cov_cutoff auto 2>/dev/null`;
@output = split(/\n/, $output);

foreach(@output){print "$_\n";}         

# end timer
my $end = time();

# report
print "\nTime taken was ", ( $end - $start ), " seconds\n";


