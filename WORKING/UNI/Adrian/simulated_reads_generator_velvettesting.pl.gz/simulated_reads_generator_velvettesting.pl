#!/usr/bin/perl
use warnings;
use List::Util 'shuffle';


# start timer
my $start = time();

##list FASTA files to use in an array

@input_file = ("simulated_reads/dm_chr_2l.fa");

##filestem

$filestem = "simulated_reads/dm_chr_2l_";


@coverage = (70);
#@coverage = (1,5,10,15,20,25,30,35,40,45,50,75,100);
@insertlength = (900);
@read_length = (75);
$paired_reads = "y"; # y is yes 
$sd = "y";
$noise = "n"; # y is yes 

# load FASTA sequences into memory

my %sequences = ();

foreach $input_file (@input_file){
	$current_seq = undef;
	open IN, "$input_file" or die "can't open file";
	while (<IN>) {
		chomp $_;
		if ($_ =~ m/^>/){
			$_ =~ s/>//g;
			if ($current_seq){		
			$current_seq =~ s/ //g;
			$sequences{"$current_header"} = "$current_seq";
			$current_seq = undef;}
			$current_header = $_;
	
		}else{
			$_ = uc($_);
			$current_seq .= "$_";
		}
	}

$sequences{"$current_header"} = "$current_seq";
close IN;
}


foreach $insert_length_mean (@insertlength){

$insert_cv = 0.2; # either set sd or cv
$insert_sdev = int($insert_length_mean * $insert_cv);
#$insert_sdev = 10;
$insert_max_min_sd = 4; #give in standard deviations
$insert_max = int($insert_length_mean + ($insert_max_min_sd * $insert_sdev)); 
$insert_min = int($insert_length_mean - ($insert_max_min_sd * $insert_sdev)); 
#noise/error rate
$noise_average = "100"; # error on average every 100 nucleotides

if ($paired_reads eq 'y'){$paired_filetag = "pr$insert_length_mean";}else{$paired_filetag = "npr";}
if ($noise eq 'y'){$noise_filetag = "noi$noise_average";}else{$noise_filetag = "nnoi";}
if ($sd eq 'y' && $paired_reads eq 'y'){$sd_filetag = "sd$insert_sdev"."_mm$insert_max_min_sd";}else{$sd_filetag = "sd0_mm0";}
 
foreach $read_length (@read_length){
	foreach $coverage (@coverage){ 

@reads =();

my $output_file = "$filestem"."$paired_filetag"."_rl$read_length"."_cov$coverage"."_$sd_filetag"."_$noise_filetag.fa";


		foreach ( keys %sequences ) {
			$seq_length = length ($sequences{$_});
			$current_sequence = $sequences{$_}; 

			

			$read_num = int(($seq_length * $coverage)/$read_length); 
			print "$_\t$seq_length\t$read_num\t$read_length\t$insert_length_mean\t$coverage\n";

			
			
			while ($read_num > 0){
			
				if ($paired_reads eq "y"){
					$insert_length = 0;

					if ($sd eq 'y'){
					while (($insert_length< $insert_min || $insert_length > $insert_max) || $insert_length < $read_length ){
						$insert_length = int(gaussian_rand() * $insert_sdev + $insert_length_mean);
					}}else {$insert_length = $insert_length_mean;}
					
					$random = int (rand($seq_length-$insert_length));    # give a random integer between 0 and n-1 the number in the brackets 
					$insert	= unpack("x$random a$insert_length", $current_sequence);
					$pair1 = unpack("x0 a$read_length", $insert);
					$offset = $insert_length - $read_length;
					$pair2 = unpack("x$offset a$read_length", $insert); 
					$pair2 = &rc($pair2);

					@pair = ($pair1,$pair2);
					@pair = shuffle(@pair); #this is probably not necessary, just incase of bias in velvet
					push (@reads, "$pair[0]");
					push (@reads, "$pair[1]");
					$read_num --;
					$read_num --;

				}else{
					$random = int (rand($seq_length-$read_length));    # give a random integer between 0 and n-1 the number in the brackets 
					$read	= unpack("x$random a$read_length", $current_sequence);
					$read_rc = &rc($read);
					@read_and_read_rc = ($read,$read_rc);
					push (@reads, "$read_and_read_rc[ rand @read_and_read_rc ]");
					$read_num --;
				}
			}



		}

print "not Fully Randomising Reads\n";
#		if ($paired_reads eq "y"){
#			#randomise maintain pairs
#			
#			$reads_count = @reads;
#			$counter = 0;
#			@paired_reads = ();
#
#			while ($counter < $reads_count){
#				push (@paired_reads, "$reads[$counter]\t$reads[$counter+1]");
#				$counter +=2;
#			}
#
#			@paired_reads = shuffle (@paired_reads);
#			@reads = ();
#
#			foreach (@paired_reads){
#				@split = split (/\t/, $_);
#				push (@reads, $split[0]);
#				push (@reads, $split[1]);
#			}
#
#			
#
#		}else{
#
#			#randomise singles
#			@reads = shuffle (@reads);
#
#		}
#add noise
print "Adding Noise\n";
		@reads_copy = ();
		if ($noise eq "y"){

			foreach $read (@reads){
				$read = &noise ($read);
				push (@reads_copy,$read);
			}
		@reads = @reads_copy;
		@reads_copy = ();
		}

		unlink("$output_file");
		open( OUT, ">>$output_file" ) or die "can't open file";
		
		$counter = 0;
		foreach (@reads){
			print OUT ">SEQUENCE_"."$counter"."_length_$read_length\n";
			print OUT "$_\n";
			$counter ++;
		}
	@reads = ();
	close OUT;
	print "Output file $output_file written!\n";

	}
}
}


# end timer
my $end = time();

# report
print "\nTime taken was ", ( $end - $start ), " seconds\n";




sub rc {
	my $initial_seq = $_[0];
	my $rc_seq = "";
	my $last_nuc;

	while ($initial_seq){
		$last_nuc = chop $initial_seq;
		$last_nuc =~ tr/[A,T,C,G]/[T,A,G,C]/;
		$rc_seq .= $last_nuc; 
	}

	return $rc_seq;

}

sub noise {
	my $initial_seq = $_[0];
	my $seq_length = length $initial_seq;
	my $noise_seq = "";
	my $offset_noise = 0; 

	while ($seq_length > 0){
		$current_nuc = unpack("x$offset_noise a1", $initial_seq);
		@nucs = ("A","T","G","C");

		if (int (rand($noise_average)) == 1){
			$noise_nuc = $current_nuc;

			while ($noise_nuc eq $current_nuc){
				@nucs = shuffle (@nucs);
				$noise_nuc = $nucs[0];
			}

			$current_nuc = $noise_nuc;
		}

		$noise_seq .= $current_nuc;

		$seq_length--;
		$offset_noise++;
	} 
return $noise_seq;
}

sub gaussian_rand {
    my ($u1, $u2);  # uniformly distributed random numbers
    my $w;          # variance, then a weight
    my ($g1, $g2);  # gaussian-distributed numbers

    do {
        $u1 = 2 * rand() - 1;
        $u2 = 2 * rand() - 1;
        $w = $u1*$u1 + $u2*$u2;
    } while ( $w >= 1 );

    $w = sqrt( (-2 * log($w))  / $w );
    $g2 = $u1 * $w;
    $g1 = $u2 * $w;
    # return both if wanted, else just one
    return $g1;
}



